gdjs.Level3Code = {};
gdjs.Level3Code.GDPlayerObjects2_1final = [];

gdjs.Level3Code.GDPlatformObjects1= [];
gdjs.Level3Code.GDPlatformObjects2= [];
gdjs.Level3Code.GDPlatformObjects3= [];
gdjs.Level3Code.GDPlatformObjects4= [];
gdjs.Level3Code.GDPlatformObjects5= [];
gdjs.Level3Code.GDPlayerObjects1= [];
gdjs.Level3Code.GDPlayerObjects2= [];
gdjs.Level3Code.GDPlayerObjects3= [];
gdjs.Level3Code.GDPlayerObjects4= [];
gdjs.Level3Code.GDPlayerObjects5= [];
gdjs.Level3Code.GDghostObjects1= [];
gdjs.Level3Code.GDghostObjects2= [];
gdjs.Level3Code.GDghostObjects3= [];
gdjs.Level3Code.GDghostObjects4= [];
gdjs.Level3Code.GDghostObjects5= [];
gdjs.Level3Code.GDGhost1RightObjects1= [];
gdjs.Level3Code.GDGhost1RightObjects2= [];
gdjs.Level3Code.GDGhost1RightObjects3= [];
gdjs.Level3Code.GDGhost1RightObjects4= [];
gdjs.Level3Code.GDGhost1RightObjects5= [];
gdjs.Level3Code.GDGhost1LeftObjects1= [];
gdjs.Level3Code.GDGhost1LeftObjects2= [];
gdjs.Level3Code.GDGhost1LeftObjects3= [];
gdjs.Level3Code.GDGhost1LeftObjects4= [];
gdjs.Level3Code.GDGhost1LeftObjects5= [];
gdjs.Level3Code.GDPlatform2Objects1= [];
gdjs.Level3Code.GDPlatform2Objects2= [];
gdjs.Level3Code.GDPlatform2Objects3= [];
gdjs.Level3Code.GDPlatform2Objects4= [];
gdjs.Level3Code.GDPlatform2Objects5= [];
gdjs.Level3Code.GDCoinObjects1= [];
gdjs.Level3Code.GDCoinObjects2= [];
gdjs.Level3Code.GDCoinObjects3= [];
gdjs.Level3Code.GDCoinObjects4= [];
gdjs.Level3Code.GDCoinObjects5= [];
gdjs.Level3Code.GDNewTextObjects1= [];
gdjs.Level3Code.GDNewTextObjects2= [];
gdjs.Level3Code.GDNewTextObjects3= [];
gdjs.Level3Code.GDNewTextObjects4= [];
gdjs.Level3Code.GDNewTextObjects5= [];
gdjs.Level3Code.GDNewText2Objects1= [];
gdjs.Level3Code.GDNewText2Objects2= [];
gdjs.Level3Code.GDNewText2Objects3= [];
gdjs.Level3Code.GDNewText2Objects4= [];
gdjs.Level3Code.GDNewText2Objects5= [];
gdjs.Level3Code.GDNewSpriteObjects1= [];
gdjs.Level3Code.GDNewSpriteObjects2= [];
gdjs.Level3Code.GDNewSpriteObjects3= [];
gdjs.Level3Code.GDNewSpriteObjects4= [];
gdjs.Level3Code.GDNewSpriteObjects5= [];
gdjs.Level3Code.GDWallObjects1= [];
gdjs.Level3Code.GDWallObjects2= [];
gdjs.Level3Code.GDWallObjects3= [];
gdjs.Level3Code.GDWallObjects4= [];
gdjs.Level3Code.GDWallObjects5= [];
gdjs.Level3Code.GDMovingfrfrfObjects1= [];
gdjs.Level3Code.GDMovingfrfrfObjects2= [];
gdjs.Level3Code.GDMovingfrfrfObjects3= [];
gdjs.Level3Code.GDMovingfrfrfObjects4= [];
gdjs.Level3Code.GDMovingfrfrfObjects5= [];
gdjs.Level3Code.GDdashObjects1= [];
gdjs.Level3Code.GDdashObjects2= [];
gdjs.Level3Code.GDdashObjects3= [];
gdjs.Level3Code.GDdashObjects4= [];
gdjs.Level3Code.GDdashObjects5= [];
gdjs.Level3Code.GDjumpghostObjects1= [];
gdjs.Level3Code.GDjumpghostObjects2= [];
gdjs.Level3Code.GDjumpghostObjects3= [];
gdjs.Level3Code.GDjumpghostObjects4= [];
gdjs.Level3Code.GDjumpghostObjects5= [];
gdjs.Level3Code.GDhitskeleObjects1= [];
gdjs.Level3Code.GDhitskeleObjects2= [];
gdjs.Level3Code.GDhitskeleObjects3= [];
gdjs.Level3Code.GDhitskeleObjects4= [];
gdjs.Level3Code.GDhitskeleObjects5= [];
gdjs.Level3Code.GDDetector_9595tm_9595Objects1= [];
gdjs.Level3Code.GDDetector_9595tm_9595Objects2= [];
gdjs.Level3Code.GDDetector_9595tm_9595Objects3= [];
gdjs.Level3Code.GDDetector_9595tm_9595Objects4= [];
gdjs.Level3Code.GDDetector_9595tm_9595Objects5= [];
gdjs.Level3Code.GDbedObjects1= [];
gdjs.Level3Code.GDbedObjects2= [];
gdjs.Level3Code.GDbedObjects3= [];
gdjs.Level3Code.GDbedObjects4= [];
gdjs.Level3Code.GDbedObjects5= [];
gdjs.Level3Code.GDBedWinObjects1= [];
gdjs.Level3Code.GDBedWinObjects2= [];
gdjs.Level3Code.GDBedWinObjects3= [];
gdjs.Level3Code.GDBedWinObjects4= [];
gdjs.Level3Code.GDBedWinObjects5= [];
gdjs.Level3Code.GDBoosterObjects1= [];
gdjs.Level3Code.GDBoosterObjects2= [];
gdjs.Level3Code.GDBoosterObjects3= [];
gdjs.Level3Code.GDBoosterObjects4= [];
gdjs.Level3Code.GDBoosterObjects5= [];
gdjs.Level3Code.GDBackgroundObjects1= [];
gdjs.Level3Code.GDBackgroundObjects2= [];
gdjs.Level3Code.GDBackgroundObjects3= [];
gdjs.Level3Code.GDBackgroundObjects4= [];
gdjs.Level3Code.GDBackgroundObjects5= [];
gdjs.Level3Code.GDSkeletonObjects1= [];
gdjs.Level3Code.GDSkeletonObjects2= [];
gdjs.Level3Code.GDSkeletonObjects3= [];
gdjs.Level3Code.GDSkeletonObjects4= [];
gdjs.Level3Code.GDSkeletonObjects5= [];
gdjs.Level3Code.GDSanity_9595BarObjects1= [];
gdjs.Level3Code.GDSanity_9595BarObjects2= [];
gdjs.Level3Code.GDSanity_9595BarObjects3= [];
gdjs.Level3Code.GDSanity_9595BarObjects4= [];
gdjs.Level3Code.GDSanity_9595BarObjects5= [];
gdjs.Level3Code.GDPlayerObjects1= [];
gdjs.Level3Code.GDPlayerObjects2= [];
gdjs.Level3Code.GDPlayerObjects3= [];
gdjs.Level3Code.GDPlayerObjects4= [];
gdjs.Level3Code.GDPlayerObjects5= [];
gdjs.Level3Code.GDBottomObjects1= [];
gdjs.Level3Code.GDBottomObjects2= [];
gdjs.Level3Code.GDBottomObjects3= [];
gdjs.Level3Code.GDBottomObjects4= [];
gdjs.Level3Code.GDBottomObjects5= [];


gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects2});
gdjs.Level3Code.asyncCallback16622836 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.Level3Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level3Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.Level3Code.asyncCallback16622836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback16625620 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.Level3Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level3Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.Level3Code.asyncCallback16625620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level3Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.Level3Code.GDSanity_9595BarObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.Level3Code.GDSanity_9595BarObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSanity_9595BarObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.Level3Code.GDSanity_9595BarObjects2[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].returnVariable(gdjs.Level3Code.GDPlayerObjects2[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("WalkLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").resumeAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("IdleLeft");
}
}}

}


{

gdjs.Level3Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Level3Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_1 = true;
        gdjs.Level3Code.GDPlayerObjects3[k] = gdjs.Level3Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level3Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level3Code.GDPlayerObjects2_1final.indexOf(gdjs.Level3Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level3Code.GDPlayerObjects2_1final.push(gdjs.Level3Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.Level3Code.GDPlayerObjects3[k] = gdjs.Level3Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level3Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level3Code.GDPlayerObjects2_1final.indexOf(gdjs.Level3Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level3Code.GDPlayerObjects2_1final.push(gdjs.Level3Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level3Code.GDPlayerObjects2_1final, gdjs.Level3Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].addForce(1200, 0, 1);
}
}
{ //Subevents
gdjs.Level3Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.Level3Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Level3Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_1 = true;
        gdjs.Level3Code.GDPlayerObjects3[k] = gdjs.Level3Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level3Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level3Code.GDPlayerObjects2_1final.indexOf(gdjs.Level3Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level3Code.GDPlayerObjects2_1final.push(gdjs.Level3Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level3Code.GDPlayerObjects2_1final, gdjs.Level3Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects2[k] = gdjs.Level3Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects2[i].addForce(-(1200), 0, 1);
}
}
{ //Subevents
gdjs.Level3Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects1[i].resetTimer("Dash");
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDGhost1LeftObjects2Objects = Hashtable.newFrom({"Ghost1Left": gdjs.Level3Code.GDGhost1LeftObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDGhost1RightObjects1Objects = Hashtable.newFrom({"Ghost1Right": gdjs.Level3Code.GDGhost1RightObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.Level3Code.GDghostObjects1});
gdjs.Level3Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level3Code.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level3Code.GDGhost1RightObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDGhost1RightObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDGhost1RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level3Code.GDGhost1LeftObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDGhost1LeftObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level3Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level3Code.GDGhost1RightObjects2);
/* Reuse gdjs.Level3Code.GDghostObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level3Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.Level3Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level3Code.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level3Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDGhost1LeftObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects2Objects, (( gdjs.Level3Code.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1LeftObjects2[0].getPointX("")), (( gdjs.Level3Code.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1LeftObjects2[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level3Code.GDGhost1RightObjects2);
/* Reuse gdjs.Level3Code.GDghostObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level3Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.Level3Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Level3Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDghostObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.Level3Code.GDghostObjects2[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level3Code.GDGhost1RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level3Code.GDghostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDGhost1RightObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDghostObjects1Objects, (( gdjs.Level3Code.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects1[0].getPointX("")), (( gdjs.Level3Code.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1RightObjects1[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level3Code.GDGhost1LeftObjects1);
/* Reuse gdjs.Level3Code.GDghostObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDghostObjects1[i].getBehavior("Animation").setAnimationName("Left");
}
}{for(var i = 0, len = gdjs.Level3Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level3Code.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1LeftObjects1[0].getPointX("")), (( gdjs.Level3Code.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDGhost1LeftObjects1[0].getPointY("")));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level3Code.GDCoinObjects2});
gdjs.Level3Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "game music (important).mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level3Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDCoinObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Level3Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Level3Code.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDNewTextObjects1[i].getBehavior("Text").setText("= " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBoosterObjects2Objects = Hashtable.newFrom({"Booster": gdjs.Level3Code.GDBoosterObjects2});
gdjs.Level3Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDPlayerObjects2[0].getPointX("")), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Booster"), gdjs.Level3Code.GDBoosterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDBoosterObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDBoosterObjects2 */
{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.Level3Code.GDBoosterObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDBoosterObjects2[0].getPointY("")) + 120, "", 0);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Booster"), gdjs.Level3Code.GDBoosterObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDBoosterObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDBoosterObjects1[i].hide();
}
}}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDetector_95959595tm_95959595Objects2Objects = Hashtable.newFrom({"Detector_tm_": gdjs.Level3Code.GDDetector_9595tm_9595Objects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects2});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.Level3Code.GDSkeletonObjects1});
gdjs.Level3Code.asyncCallback16641668 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects5[i].setY(gdjs.Level3Code.GDPlayerObjects5[i].getY() - (60));
}
}}
gdjs.Level3Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level3Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback16641668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback16640980 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects4);

{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects4[i].getBehavior("Resizable").setHeight(gdjs.Level3Code.GDSkeletonObjects4[i].getBehavior("Resizable").getHeight() - (60));
}
}{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects4[i].setY(gdjs.Level3Code.GDPlayerObjects4[i].getY() - (65));
}
}
{ //Subevents
gdjs.Level3Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.Level3Code.GDSkeletonObjects3) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback16640980(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.asyncCallback16640276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects3);

{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects3.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects3[i].getBehavior("Resizable").setHeight(gdjs.Level3Code.GDSkeletonObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.Level3Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level3Code.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level3Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
for (const obj of gdjs.Level3Code.GDSkeletonObjects2) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level3Code.asyncCallback16640276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level3Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level3Code.GDPlayerObjects1, gdjs.Level3Code.GDPlayerObjects2);

gdjs.copyArray(gdjs.Level3Code.GDSkeletonObjects1, gdjs.Level3Code.GDSkeletonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDPlayerObjects2[0].getPointY("Feet")) <= (( gdjs.Level3Code.GDSkeletonObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDSkeletonObjects2[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("Resizable").setHeight(gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.Level3Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level3Code.GDPlayerObjects1 */
/* Reuse gdjs.Level3Code.GDSkeletonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level3Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDPlayerObjects1[0].getPointY("Feet")) > (( gdjs.Level3Code.GDSkeletonObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDSkeletonObjects1[0].getPointY("Head")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.Level3Code.GDSanity_9595BarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.Level3Code.GDSanity_9595BarObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDSanity_9595BarObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.Level3Code.GDSanity_9595BarObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.Level3Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDPlayerObjects1[i].returnVariable(gdjs.Level3Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level3Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDSkeletonObjects2[i].getX() < (( gdjs.Level3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDSkeletonObjects2[k] = gdjs.Level3Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDSkeletonObjects2[i].getVariableBoolean(gdjs.Level3Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDSkeletonObjects2[k] = gdjs.Level3Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDSkeletonObjects2[i].getX() > (( gdjs.Level3Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level3Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDSkeletonObjects2[k] = gdjs.Level3Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level3Code.GDSkeletonObjects2[i].getVariableBoolean(gdjs.Level3Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDSkeletonObjects2[k] = gdjs.Level3Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level3Code.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Left");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.Level3Code.GDDetector_9595tm_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDDetector_95959595tm_95959595Objects2Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.Level3Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDSkeletonObjects2[i].setVariableBoolean(gdjs.Level3Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.Level3Code.GDDetector_9595tm_9595Objects2);
{for(var i = 0, len = gdjs.Level3Code.GDDetector_9595tm_9595Objects2.length ;i < len;++i) {
    gdjs.Level3Code.GDDetector_9595tm_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level3Code.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level3Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level3Code.GDPlayerObjects1});
gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDbedObjects1Objects = Hashtable.newFrom({"bed": gdjs.Level3Code.GDbedObjects1});
gdjs.Level3Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level3Code.eventsList2(runtimeScene);
}


{


gdjs.Level3Code.eventsList3(runtimeScene);
}


{


gdjs.Level3Code.eventsList4(runtimeScene);
}


{


gdjs.Level3Code.eventsList5(runtimeScene);
}


{


gdjs.Level3Code.eventsList10(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bed"), gdjs.Level3Code.GDbedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDPlayerObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_9546Level3Code_9546GDbedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level4", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level3Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level3Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level3Code.GDPlayerObjects1[i].getVariableNumber(gdjs.Level3Code.GDPlayerObjects1[i].getVariables().getFromIndex(1)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level3Code.GDPlayerObjects1[k] = gdjs.Level3Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level3Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Level3Code.GDWallObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDWallObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDWallObjects1[i].hide();
}
}}

}


};

gdjs.Level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level3Code.GDPlatformObjects1.length = 0;
gdjs.Level3Code.GDPlatformObjects2.length = 0;
gdjs.Level3Code.GDPlatformObjects3.length = 0;
gdjs.Level3Code.GDPlatformObjects4.length = 0;
gdjs.Level3Code.GDPlatformObjects5.length = 0;
gdjs.Level3Code.GDPlayerObjects1.length = 0;
gdjs.Level3Code.GDPlayerObjects2.length = 0;
gdjs.Level3Code.GDPlayerObjects3.length = 0;
gdjs.Level3Code.GDPlayerObjects4.length = 0;
gdjs.Level3Code.GDPlayerObjects5.length = 0;
gdjs.Level3Code.GDghostObjects1.length = 0;
gdjs.Level3Code.GDghostObjects2.length = 0;
gdjs.Level3Code.GDghostObjects3.length = 0;
gdjs.Level3Code.GDghostObjects4.length = 0;
gdjs.Level3Code.GDghostObjects5.length = 0;
gdjs.Level3Code.GDGhost1RightObjects1.length = 0;
gdjs.Level3Code.GDGhost1RightObjects2.length = 0;
gdjs.Level3Code.GDGhost1RightObjects3.length = 0;
gdjs.Level3Code.GDGhost1RightObjects4.length = 0;
gdjs.Level3Code.GDGhost1RightObjects5.length = 0;
gdjs.Level3Code.GDGhost1LeftObjects1.length = 0;
gdjs.Level3Code.GDGhost1LeftObjects2.length = 0;
gdjs.Level3Code.GDGhost1LeftObjects3.length = 0;
gdjs.Level3Code.GDGhost1LeftObjects4.length = 0;
gdjs.Level3Code.GDGhost1LeftObjects5.length = 0;
gdjs.Level3Code.GDPlatform2Objects1.length = 0;
gdjs.Level3Code.GDPlatform2Objects2.length = 0;
gdjs.Level3Code.GDPlatform2Objects3.length = 0;
gdjs.Level3Code.GDPlatform2Objects4.length = 0;
gdjs.Level3Code.GDPlatform2Objects5.length = 0;
gdjs.Level3Code.GDCoinObjects1.length = 0;
gdjs.Level3Code.GDCoinObjects2.length = 0;
gdjs.Level3Code.GDCoinObjects3.length = 0;
gdjs.Level3Code.GDCoinObjects4.length = 0;
gdjs.Level3Code.GDCoinObjects5.length = 0;
gdjs.Level3Code.GDNewTextObjects1.length = 0;
gdjs.Level3Code.GDNewTextObjects2.length = 0;
gdjs.Level3Code.GDNewTextObjects3.length = 0;
gdjs.Level3Code.GDNewTextObjects4.length = 0;
gdjs.Level3Code.GDNewTextObjects5.length = 0;
gdjs.Level3Code.GDNewText2Objects1.length = 0;
gdjs.Level3Code.GDNewText2Objects2.length = 0;
gdjs.Level3Code.GDNewText2Objects3.length = 0;
gdjs.Level3Code.GDNewText2Objects4.length = 0;
gdjs.Level3Code.GDNewText2Objects5.length = 0;
gdjs.Level3Code.GDNewSpriteObjects1.length = 0;
gdjs.Level3Code.GDNewSpriteObjects2.length = 0;
gdjs.Level3Code.GDNewSpriteObjects3.length = 0;
gdjs.Level3Code.GDNewSpriteObjects4.length = 0;
gdjs.Level3Code.GDNewSpriteObjects5.length = 0;
gdjs.Level3Code.GDWallObjects1.length = 0;
gdjs.Level3Code.GDWallObjects2.length = 0;
gdjs.Level3Code.GDWallObjects3.length = 0;
gdjs.Level3Code.GDWallObjects4.length = 0;
gdjs.Level3Code.GDWallObjects5.length = 0;
gdjs.Level3Code.GDMovingfrfrfObjects1.length = 0;
gdjs.Level3Code.GDMovingfrfrfObjects2.length = 0;
gdjs.Level3Code.GDMovingfrfrfObjects3.length = 0;
gdjs.Level3Code.GDMovingfrfrfObjects4.length = 0;
gdjs.Level3Code.GDMovingfrfrfObjects5.length = 0;
gdjs.Level3Code.GDdashObjects1.length = 0;
gdjs.Level3Code.GDdashObjects2.length = 0;
gdjs.Level3Code.GDdashObjects3.length = 0;
gdjs.Level3Code.GDdashObjects4.length = 0;
gdjs.Level3Code.GDdashObjects5.length = 0;
gdjs.Level3Code.GDjumpghostObjects1.length = 0;
gdjs.Level3Code.GDjumpghostObjects2.length = 0;
gdjs.Level3Code.GDjumpghostObjects3.length = 0;
gdjs.Level3Code.GDjumpghostObjects4.length = 0;
gdjs.Level3Code.GDjumpghostObjects5.length = 0;
gdjs.Level3Code.GDhitskeleObjects1.length = 0;
gdjs.Level3Code.GDhitskeleObjects2.length = 0;
gdjs.Level3Code.GDhitskeleObjects3.length = 0;
gdjs.Level3Code.GDhitskeleObjects4.length = 0;
gdjs.Level3Code.GDhitskeleObjects5.length = 0;
gdjs.Level3Code.GDDetector_9595tm_9595Objects1.length = 0;
gdjs.Level3Code.GDDetector_9595tm_9595Objects2.length = 0;
gdjs.Level3Code.GDDetector_9595tm_9595Objects3.length = 0;
gdjs.Level3Code.GDDetector_9595tm_9595Objects4.length = 0;
gdjs.Level3Code.GDDetector_9595tm_9595Objects5.length = 0;
gdjs.Level3Code.GDbedObjects1.length = 0;
gdjs.Level3Code.GDbedObjects2.length = 0;
gdjs.Level3Code.GDbedObjects3.length = 0;
gdjs.Level3Code.GDbedObjects4.length = 0;
gdjs.Level3Code.GDbedObjects5.length = 0;
gdjs.Level3Code.GDBedWinObjects1.length = 0;
gdjs.Level3Code.GDBedWinObjects2.length = 0;
gdjs.Level3Code.GDBedWinObjects3.length = 0;
gdjs.Level3Code.GDBedWinObjects4.length = 0;
gdjs.Level3Code.GDBedWinObjects5.length = 0;
gdjs.Level3Code.GDBoosterObjects1.length = 0;
gdjs.Level3Code.GDBoosterObjects2.length = 0;
gdjs.Level3Code.GDBoosterObjects3.length = 0;
gdjs.Level3Code.GDBoosterObjects4.length = 0;
gdjs.Level3Code.GDBoosterObjects5.length = 0;
gdjs.Level3Code.GDBackgroundObjects1.length = 0;
gdjs.Level3Code.GDBackgroundObjects2.length = 0;
gdjs.Level3Code.GDBackgroundObjects3.length = 0;
gdjs.Level3Code.GDBackgroundObjects4.length = 0;
gdjs.Level3Code.GDBackgroundObjects5.length = 0;
gdjs.Level3Code.GDSkeletonObjects1.length = 0;
gdjs.Level3Code.GDSkeletonObjects2.length = 0;
gdjs.Level3Code.GDSkeletonObjects3.length = 0;
gdjs.Level3Code.GDSkeletonObjects4.length = 0;
gdjs.Level3Code.GDSkeletonObjects5.length = 0;
gdjs.Level3Code.GDSanity_9595BarObjects1.length = 0;
gdjs.Level3Code.GDSanity_9595BarObjects2.length = 0;
gdjs.Level3Code.GDSanity_9595BarObjects3.length = 0;
gdjs.Level3Code.GDSanity_9595BarObjects4.length = 0;
gdjs.Level3Code.GDSanity_9595BarObjects5.length = 0;
gdjs.Level3Code.GDPlayerObjects1.length = 0;
gdjs.Level3Code.GDPlayerObjects2.length = 0;
gdjs.Level3Code.GDPlayerObjects3.length = 0;
gdjs.Level3Code.GDPlayerObjects4.length = 0;
gdjs.Level3Code.GDPlayerObjects5.length = 0;
gdjs.Level3Code.GDBottomObjects1.length = 0;
gdjs.Level3Code.GDBottomObjects2.length = 0;
gdjs.Level3Code.GDBottomObjects3.length = 0;
gdjs.Level3Code.GDBottomObjects4.length = 0;
gdjs.Level3Code.GDBottomObjects5.length = 0;

gdjs.Level3Code.eventsList11(runtimeScene);

return;

}

gdjs['Level3Code'] = gdjs.Level3Code;
