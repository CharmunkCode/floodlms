gdjs.Level2Code = {};
gdjs.Level2Code.GDPlayerObjects2_1final = [];

gdjs.Level2Code.GDPlatformObjects1= [];
gdjs.Level2Code.GDPlatformObjects2= [];
gdjs.Level2Code.GDPlatformObjects3= [];
gdjs.Level2Code.GDPlatformObjects4= [];
gdjs.Level2Code.GDPlatformObjects5= [];
gdjs.Level2Code.GDPlayerObjects1= [];
gdjs.Level2Code.GDPlayerObjects2= [];
gdjs.Level2Code.GDPlayerObjects3= [];
gdjs.Level2Code.GDPlayerObjects4= [];
gdjs.Level2Code.GDPlayerObjects5= [];
gdjs.Level2Code.GDghostObjects1= [];
gdjs.Level2Code.GDghostObjects2= [];
gdjs.Level2Code.GDghostObjects3= [];
gdjs.Level2Code.GDghostObjects4= [];
gdjs.Level2Code.GDghostObjects5= [];
gdjs.Level2Code.GDGhost1RightObjects1= [];
gdjs.Level2Code.GDGhost1RightObjects2= [];
gdjs.Level2Code.GDGhost1RightObjects3= [];
gdjs.Level2Code.GDGhost1RightObjects4= [];
gdjs.Level2Code.GDGhost1RightObjects5= [];
gdjs.Level2Code.GDGhost1LeftObjects1= [];
gdjs.Level2Code.GDGhost1LeftObjects2= [];
gdjs.Level2Code.GDGhost1LeftObjects3= [];
gdjs.Level2Code.GDGhost1LeftObjects4= [];
gdjs.Level2Code.GDGhost1LeftObjects5= [];
gdjs.Level2Code.GDPlatform2Objects1= [];
gdjs.Level2Code.GDPlatform2Objects2= [];
gdjs.Level2Code.GDPlatform2Objects3= [];
gdjs.Level2Code.GDPlatform2Objects4= [];
gdjs.Level2Code.GDPlatform2Objects5= [];
gdjs.Level2Code.GDCoinObjects1= [];
gdjs.Level2Code.GDCoinObjects2= [];
gdjs.Level2Code.GDCoinObjects3= [];
gdjs.Level2Code.GDCoinObjects4= [];
gdjs.Level2Code.GDCoinObjects5= [];
gdjs.Level2Code.GDNewTextObjects1= [];
gdjs.Level2Code.GDNewTextObjects2= [];
gdjs.Level2Code.GDNewTextObjects3= [];
gdjs.Level2Code.GDNewTextObjects4= [];
gdjs.Level2Code.GDNewTextObjects5= [];
gdjs.Level2Code.GDNewText2Objects1= [];
gdjs.Level2Code.GDNewText2Objects2= [];
gdjs.Level2Code.GDNewText2Objects3= [];
gdjs.Level2Code.GDNewText2Objects4= [];
gdjs.Level2Code.GDNewText2Objects5= [];
gdjs.Level2Code.GDNewSpriteObjects1= [];
gdjs.Level2Code.GDNewSpriteObjects2= [];
gdjs.Level2Code.GDNewSpriteObjects3= [];
gdjs.Level2Code.GDNewSpriteObjects4= [];
gdjs.Level2Code.GDNewSpriteObjects5= [];
gdjs.Level2Code.GDWallObjects1= [];
gdjs.Level2Code.GDWallObjects2= [];
gdjs.Level2Code.GDWallObjects3= [];
gdjs.Level2Code.GDWallObjects4= [];
gdjs.Level2Code.GDWallObjects5= [];
gdjs.Level2Code.GDMovingfrfrfObjects1= [];
gdjs.Level2Code.GDMovingfrfrfObjects2= [];
gdjs.Level2Code.GDMovingfrfrfObjects3= [];
gdjs.Level2Code.GDMovingfrfrfObjects4= [];
gdjs.Level2Code.GDMovingfrfrfObjects5= [];
gdjs.Level2Code.GDdashObjects1= [];
gdjs.Level2Code.GDdashObjects2= [];
gdjs.Level2Code.GDdashObjects3= [];
gdjs.Level2Code.GDdashObjects4= [];
gdjs.Level2Code.GDdashObjects5= [];
gdjs.Level2Code.GDjumpghostObjects1= [];
gdjs.Level2Code.GDjumpghostObjects2= [];
gdjs.Level2Code.GDjumpghostObjects3= [];
gdjs.Level2Code.GDjumpghostObjects4= [];
gdjs.Level2Code.GDjumpghostObjects5= [];
gdjs.Level2Code.GDhitskeleObjects1= [];
gdjs.Level2Code.GDhitskeleObjects2= [];
gdjs.Level2Code.GDhitskeleObjects3= [];
gdjs.Level2Code.GDhitskeleObjects4= [];
gdjs.Level2Code.GDhitskeleObjects5= [];
gdjs.Level2Code.GDDetector_9595tm_9595Objects1= [];
gdjs.Level2Code.GDDetector_9595tm_9595Objects2= [];
gdjs.Level2Code.GDDetector_9595tm_9595Objects3= [];
gdjs.Level2Code.GDDetector_9595tm_9595Objects4= [];
gdjs.Level2Code.GDDetector_9595tm_9595Objects5= [];
gdjs.Level2Code.GDbedObjects1= [];
gdjs.Level2Code.GDbedObjects2= [];
gdjs.Level2Code.GDbedObjects3= [];
gdjs.Level2Code.GDbedObjects4= [];
gdjs.Level2Code.GDbedObjects5= [];
gdjs.Level2Code.GDBedWinObjects1= [];
gdjs.Level2Code.GDBedWinObjects2= [];
gdjs.Level2Code.GDBedWinObjects3= [];
gdjs.Level2Code.GDBedWinObjects4= [];
gdjs.Level2Code.GDBedWinObjects5= [];
gdjs.Level2Code.GDBackgroundObjects1= [];
gdjs.Level2Code.GDBackgroundObjects2= [];
gdjs.Level2Code.GDBackgroundObjects3= [];
gdjs.Level2Code.GDBackgroundObjects4= [];
gdjs.Level2Code.GDBackgroundObjects5= [];
gdjs.Level2Code.GDSkeletonObjects1= [];
gdjs.Level2Code.GDSkeletonObjects2= [];
gdjs.Level2Code.GDSkeletonObjects3= [];
gdjs.Level2Code.GDSkeletonObjects4= [];
gdjs.Level2Code.GDSkeletonObjects5= [];
gdjs.Level2Code.GDSanity_9595BarObjects1= [];
gdjs.Level2Code.GDSanity_9595BarObjects2= [];
gdjs.Level2Code.GDSanity_9595BarObjects3= [];
gdjs.Level2Code.GDSanity_9595BarObjects4= [];
gdjs.Level2Code.GDSanity_9595BarObjects5= [];
gdjs.Level2Code.GDPlayerObjects1= [];
gdjs.Level2Code.GDPlayerObjects2= [];
gdjs.Level2Code.GDPlayerObjects3= [];
gdjs.Level2Code.GDPlayerObjects4= [];
gdjs.Level2Code.GDPlayerObjects5= [];
gdjs.Level2Code.GDBottomObjects1= [];
gdjs.Level2Code.GDBottomObjects2= [];
gdjs.Level2Code.GDBottomObjects3= [];
gdjs.Level2Code.GDBottomObjects4= [];
gdjs.Level2Code.GDBottomObjects5= [];


gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects2});
gdjs.Level2Code.asyncCallback16502180 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.Level2Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level2Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.Level2Code.asyncCallback16502180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level2Code.asyncCallback16504964 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").setCanNotAirJump();
}
}}
gdjs.Level2Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level2Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.15), (runtimeScene) => (gdjs.Level2Code.asyncCallback16504964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level2Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level2Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.Level2Code.GDSanity_9595BarObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.Level2Code.GDSanity_9595BarObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSanity_9595BarObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.Level2Code.GDSanity_9595BarObjects2[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].returnVariable(gdjs.Level2Code.GDPlayerObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() != "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("WalkLeft");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").resumeAnimation();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").getCurrentSpeed() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].resetTimer("Idle");
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("IdleLeft");
}
}}

}


{

gdjs.Level2Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Level2Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkRight" ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects2_1final.indexOf(gdjs.Level2Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects2_1final.push(gdjs.Level2Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects2_1final.indexOf(gdjs.Level2Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects2_1final.push(gdjs.Level2Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2_1final, gdjs.Level2Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].addForce(1200, 0, 1);
}
}
{ //Subevents
gdjs.Level2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.Level2Code.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Level2Code.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("Animation").getAnimationName() == "WalkLeft" ) {
        isConditionTrue_1 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Level2Code.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.Level2Code.GDPlayerObjects2_1final.indexOf(gdjs.Level2Code.GDPlayerObjects3[j]) === -1 )
            gdjs.Level2Code.GDPlayerObjects2_1final.push(gdjs.Level2Code.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2_1final, gdjs.Level2Code.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 1 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].resetTimer("Dash");
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].addForce(-(1200), 0, 1);
}
}
{ //Subevents
gdjs.Level2Code.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].resetTimer("Dash");
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDGhost1LeftObjects2Objects = Hashtable.newFrom({"Ghost1Left": gdjs.Level2Code.GDGhost1LeftObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDGhost1RightObjects1Objects = Hashtable.newFrom({"Ghost1Right": gdjs.Level2Code.GDGhost1RightObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects1Objects = Hashtable.newFrom({"ghost": gdjs.Level2Code.GDghostObjects1});
gdjs.Level2Code.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level2Code.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level2Code.GDGhost1RightObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDGhost1RightObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDGhost1RightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Level2Code.GDGhost1LeftObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDGhost1LeftObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level2Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level2Code.GDGhost1RightObjects2);
/* Reuse gdjs.Level2Code.GDghostObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level2Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.Level2Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level2Code.GDGhost1LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level2Code.GDghostObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDGhost1LeftObjects2Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects2Objects, (( gdjs.Level2Code.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1LeftObjects2[0].getPointX("")), (( gdjs.Level2Code.GDGhost1LeftObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1LeftObjects2[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level2Code.GDGhost1RightObjects2);
/* Reuse gdjs.Level2Code.GDghostObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDghostObjects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level2Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects2[0].getPointX("")), (( gdjs.Level2Code.GDGhost1RightObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Level2Code.GDghostObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDghostObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.Level2Code.GDghostObjects2[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost1Right"), gdjs.Level2Code.GDGhost1RightObjects1);
gdjs.copyArray(runtimeScene.getObjects("ghost"), gdjs.Level2Code.GDghostObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDGhost1RightObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDghostObjects1Objects, (( gdjs.Level2Code.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects1[0].getPointX("")), (( gdjs.Level2Code.GDGhost1RightObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1RightObjects1[0].getPointY("")), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ghost1Left"), gdjs.Level2Code.GDGhost1LeftObjects1);
/* Reuse gdjs.Level2Code.GDghostObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDghostObjects1[i].getBehavior("Animation").setAnimationName("Left");
}
}{for(var i = 0, len = gdjs.Level2Code.GDghostObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDghostObjects1[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.Level2Code.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1LeftObjects1[0].getPointX("")), (( gdjs.Level2Code.GDGhost1LeftObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDGhost1LeftObjects1[0].getPointY("")));
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level2Code.GDCoinObjects2});
gdjs.Level2Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "game music (important).mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level2Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDCoinObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.Level2Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Level2Code.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDNewTextObjects1[i].getBehavior("Text").setText("= " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0))));
}
}}

}


};gdjs.Level2Code.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Level2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDetector_95959595tm_95959595Objects2Objects = Hashtable.newFrom({"Detector_tm_": gdjs.Level2Code.GDDetector_9595tm_9595Objects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDSkeletonObjects1Objects = Hashtable.newFrom({"Skeleton": gdjs.Level2Code.GDSkeletonObjects1});
gdjs.Level2Code.asyncCallback16519884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects5);

{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects5.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects5[i].setY(gdjs.Level2Code.GDPlayerObjects5[i].getY() - (60));
}
}}
gdjs.Level2Code.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.Level2Code.GDPlayerObjects4) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level2Code.asyncCallback16519884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level2Code.asyncCallback16519196 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects4);

{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects4[i].getBehavior("Resizable").setHeight(gdjs.Level2Code.GDSkeletonObjects4[i].getBehavior("Resizable").getHeight() - (60));
}
}{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects4.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects4[i].setY(gdjs.Level2Code.GDPlayerObjects4[i].getY() - (65));
}
}
{ //Subevents
gdjs.Level2Code.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level2Code.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Player as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.Level2Code.GDSkeletonObjects3) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level2Code.asyncCallback16519196(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level2Code.asyncCallback16518492 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects3);

{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects3[i].getBehavior("Resizable").setHeight(gdjs.Level2Code.GDSkeletonObjects3[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.Level2Code.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Level2Code.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Level2Code.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
for (const obj of gdjs.Level2Code.GDSkeletonObjects2) asyncObjectsList.addObject("Skeleton", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Level2Code.asyncCallback16518492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Level2Code.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects2);

gdjs.copyArray(gdjs.Level2Code.GDSkeletonObjects1, gdjs.Level2Code.GDSkeletonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getPointY("Feet")) <= (( gdjs.Level2Code.GDSkeletonObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDSkeletonObjects2[0].getPointY("Head")));
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("Resizable").setHeight(gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("Resizable").getHeight() - (60));
}
}
{ //Subevents
gdjs.Level2Code.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
/* Reuse gdjs.Level2Code.GDSkeletonObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ((( gdjs.Level2Code.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects1[0].getPointY("Feet")) > (( gdjs.Level2Code.GDSkeletonObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDSkeletonObjects1[0].getPointY("Head")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Cooldown") >= 0.5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sanity_Bar"), gdjs.Level2Code.GDSanity_9595BarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}{for(var i = 0, len = gdjs.Level2Code.GDSanity_9595BarObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDSanity_9595BarObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.Level2Code.GDSanity_9595BarObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects1[i].returnVariable(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0.1, 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDSkeletonObjects2[i].getX() < (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDSkeletonObjects2[k] = gdjs.Level2Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDSkeletonObjects2[i].getVariableBoolean(gdjs.Level2Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDSkeletonObjects2[k] = gdjs.Level2Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Right");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDSkeletonObjects2[i].getX() > (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDSkeletonObjects2[k] = gdjs.Level2Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDSkeletonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDSkeletonObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDSkeletonObjects2[i].getVariableBoolean(gdjs.Level2Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDSkeletonObjects2[k] = gdjs.Level2Code.GDSkeletonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDSkeletonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDSkeletonObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("Animation").setAnimationName("Walking Left");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.Level2Code.GDDetector_9595tm_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDetector_95959595tm_95959595Objects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDSkeletonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDSkeletonObjects2[i].setVariableBoolean(gdjs.Level2Code.GDSkeletonObjects2[i].getVariables().getFromIndex(0), true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Detector_tm_"), gdjs.Level2Code.GDDetector_9595tm_9595Objects2);
{for(var i = 0, len = gdjs.Level2Code.GDDetector_9595tm_9595Objects2.length ;i < len;++i) {
    gdjs.Level2Code.GDDetector_9595tm_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Level2Code.GDSkeletonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDSkeletonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDbedObjects1Objects = Hashtable.newFrom({"bed": gdjs.Level2Code.GDbedObjects1});
gdjs.Level2Code.eventsList11 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList2(runtimeScene);
}


{


gdjs.Level2Code.eventsList3(runtimeScene);
}


{


gdjs.Level2Code.eventsList4(runtimeScene);
}


{


gdjs.Level2Code.eventsList5(runtimeScene);
}


{


gdjs.Level2Code.eventsList10(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Cooldown");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects1[i].getVariableNumber(gdjs.Level2Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects1[k] = gdjs.Level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("bed"), gdjs.Level2Code.GDbedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDbedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level3", false);
}}

}


};

gdjs.Level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level2Code.GDPlatformObjects1.length = 0;
gdjs.Level2Code.GDPlatformObjects2.length = 0;
gdjs.Level2Code.GDPlatformObjects3.length = 0;
gdjs.Level2Code.GDPlatformObjects4.length = 0;
gdjs.Level2Code.GDPlatformObjects5.length = 0;
gdjs.Level2Code.GDPlayerObjects1.length = 0;
gdjs.Level2Code.GDPlayerObjects2.length = 0;
gdjs.Level2Code.GDPlayerObjects3.length = 0;
gdjs.Level2Code.GDPlayerObjects4.length = 0;
gdjs.Level2Code.GDPlayerObjects5.length = 0;
gdjs.Level2Code.GDghostObjects1.length = 0;
gdjs.Level2Code.GDghostObjects2.length = 0;
gdjs.Level2Code.GDghostObjects3.length = 0;
gdjs.Level2Code.GDghostObjects4.length = 0;
gdjs.Level2Code.GDghostObjects5.length = 0;
gdjs.Level2Code.GDGhost1RightObjects1.length = 0;
gdjs.Level2Code.GDGhost1RightObjects2.length = 0;
gdjs.Level2Code.GDGhost1RightObjects3.length = 0;
gdjs.Level2Code.GDGhost1RightObjects4.length = 0;
gdjs.Level2Code.GDGhost1RightObjects5.length = 0;
gdjs.Level2Code.GDGhost1LeftObjects1.length = 0;
gdjs.Level2Code.GDGhost1LeftObjects2.length = 0;
gdjs.Level2Code.GDGhost1LeftObjects3.length = 0;
gdjs.Level2Code.GDGhost1LeftObjects4.length = 0;
gdjs.Level2Code.GDGhost1LeftObjects5.length = 0;
gdjs.Level2Code.GDPlatform2Objects1.length = 0;
gdjs.Level2Code.GDPlatform2Objects2.length = 0;
gdjs.Level2Code.GDPlatform2Objects3.length = 0;
gdjs.Level2Code.GDPlatform2Objects4.length = 0;
gdjs.Level2Code.GDPlatform2Objects5.length = 0;
gdjs.Level2Code.GDCoinObjects1.length = 0;
gdjs.Level2Code.GDCoinObjects2.length = 0;
gdjs.Level2Code.GDCoinObjects3.length = 0;
gdjs.Level2Code.GDCoinObjects4.length = 0;
gdjs.Level2Code.GDCoinObjects5.length = 0;
gdjs.Level2Code.GDNewTextObjects1.length = 0;
gdjs.Level2Code.GDNewTextObjects2.length = 0;
gdjs.Level2Code.GDNewTextObjects3.length = 0;
gdjs.Level2Code.GDNewTextObjects4.length = 0;
gdjs.Level2Code.GDNewTextObjects5.length = 0;
gdjs.Level2Code.GDNewText2Objects1.length = 0;
gdjs.Level2Code.GDNewText2Objects2.length = 0;
gdjs.Level2Code.GDNewText2Objects3.length = 0;
gdjs.Level2Code.GDNewText2Objects4.length = 0;
gdjs.Level2Code.GDNewText2Objects5.length = 0;
gdjs.Level2Code.GDNewSpriteObjects1.length = 0;
gdjs.Level2Code.GDNewSpriteObjects2.length = 0;
gdjs.Level2Code.GDNewSpriteObjects3.length = 0;
gdjs.Level2Code.GDNewSpriteObjects4.length = 0;
gdjs.Level2Code.GDNewSpriteObjects5.length = 0;
gdjs.Level2Code.GDWallObjects1.length = 0;
gdjs.Level2Code.GDWallObjects2.length = 0;
gdjs.Level2Code.GDWallObjects3.length = 0;
gdjs.Level2Code.GDWallObjects4.length = 0;
gdjs.Level2Code.GDWallObjects5.length = 0;
gdjs.Level2Code.GDMovingfrfrfObjects1.length = 0;
gdjs.Level2Code.GDMovingfrfrfObjects2.length = 0;
gdjs.Level2Code.GDMovingfrfrfObjects3.length = 0;
gdjs.Level2Code.GDMovingfrfrfObjects4.length = 0;
gdjs.Level2Code.GDMovingfrfrfObjects5.length = 0;
gdjs.Level2Code.GDdashObjects1.length = 0;
gdjs.Level2Code.GDdashObjects2.length = 0;
gdjs.Level2Code.GDdashObjects3.length = 0;
gdjs.Level2Code.GDdashObjects4.length = 0;
gdjs.Level2Code.GDdashObjects5.length = 0;
gdjs.Level2Code.GDjumpghostObjects1.length = 0;
gdjs.Level2Code.GDjumpghostObjects2.length = 0;
gdjs.Level2Code.GDjumpghostObjects3.length = 0;
gdjs.Level2Code.GDjumpghostObjects4.length = 0;
gdjs.Level2Code.GDjumpghostObjects5.length = 0;
gdjs.Level2Code.GDhitskeleObjects1.length = 0;
gdjs.Level2Code.GDhitskeleObjects2.length = 0;
gdjs.Level2Code.GDhitskeleObjects3.length = 0;
gdjs.Level2Code.GDhitskeleObjects4.length = 0;
gdjs.Level2Code.GDhitskeleObjects5.length = 0;
gdjs.Level2Code.GDDetector_9595tm_9595Objects1.length = 0;
gdjs.Level2Code.GDDetector_9595tm_9595Objects2.length = 0;
gdjs.Level2Code.GDDetector_9595tm_9595Objects3.length = 0;
gdjs.Level2Code.GDDetector_9595tm_9595Objects4.length = 0;
gdjs.Level2Code.GDDetector_9595tm_9595Objects5.length = 0;
gdjs.Level2Code.GDbedObjects1.length = 0;
gdjs.Level2Code.GDbedObjects2.length = 0;
gdjs.Level2Code.GDbedObjects3.length = 0;
gdjs.Level2Code.GDbedObjects4.length = 0;
gdjs.Level2Code.GDbedObjects5.length = 0;
gdjs.Level2Code.GDBedWinObjects1.length = 0;
gdjs.Level2Code.GDBedWinObjects2.length = 0;
gdjs.Level2Code.GDBedWinObjects3.length = 0;
gdjs.Level2Code.GDBedWinObjects4.length = 0;
gdjs.Level2Code.GDBedWinObjects5.length = 0;
gdjs.Level2Code.GDBackgroundObjects1.length = 0;
gdjs.Level2Code.GDBackgroundObjects2.length = 0;
gdjs.Level2Code.GDBackgroundObjects3.length = 0;
gdjs.Level2Code.GDBackgroundObjects4.length = 0;
gdjs.Level2Code.GDBackgroundObjects5.length = 0;
gdjs.Level2Code.GDSkeletonObjects1.length = 0;
gdjs.Level2Code.GDSkeletonObjects2.length = 0;
gdjs.Level2Code.GDSkeletonObjects3.length = 0;
gdjs.Level2Code.GDSkeletonObjects4.length = 0;
gdjs.Level2Code.GDSkeletonObjects5.length = 0;
gdjs.Level2Code.GDSanity_9595BarObjects1.length = 0;
gdjs.Level2Code.GDSanity_9595BarObjects2.length = 0;
gdjs.Level2Code.GDSanity_9595BarObjects3.length = 0;
gdjs.Level2Code.GDSanity_9595BarObjects4.length = 0;
gdjs.Level2Code.GDSanity_9595BarObjects5.length = 0;
gdjs.Level2Code.GDPlayerObjects1.length = 0;
gdjs.Level2Code.GDPlayerObjects2.length = 0;
gdjs.Level2Code.GDPlayerObjects3.length = 0;
gdjs.Level2Code.GDPlayerObjects4.length = 0;
gdjs.Level2Code.GDPlayerObjects5.length = 0;
gdjs.Level2Code.GDBottomObjects1.length = 0;
gdjs.Level2Code.GDBottomObjects2.length = 0;
gdjs.Level2Code.GDBottomObjects3.length = 0;
gdjs.Level2Code.GDBottomObjects4.length = 0;
gdjs.Level2Code.GDBottomObjects5.length = 0;

gdjs.Level2Code.eventsList11(runtimeScene);

return;

}

gdjs['Level2Code'] = gdjs.Level2Code;
