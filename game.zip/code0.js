gdjs.EndCode = {};
gdjs.EndCode.GDTitleObjects1= [];
gdjs.EndCode.GDTitleObjects2= [];
gdjs.EndCode.GDWhiteSquareDecoratedButtonObjects1= [];
gdjs.EndCode.GDWhiteSquareDecoratedButtonObjects2= [];
gdjs.EndCode.GDTeleportlineObjects1= [];
gdjs.EndCode.GDTeleportlineObjects2= [];
gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.EndCode.GDSettingsObjects1= [];
gdjs.EndCode.GDSettingsObjects2= [];
gdjs.EndCode.GDNewTextObjects1= [];
gdjs.EndCode.GDNewTextObjects2= [];
gdjs.EndCode.GDBackgroundObjects1= [];
gdjs.EndCode.GDBackgroundObjects2= [];
gdjs.EndCode.GDSkeletonObjects1= [];
gdjs.EndCode.GDSkeletonObjects2= [];
gdjs.EndCode.GDSanity_9595BarObjects1= [];
gdjs.EndCode.GDSanity_9595BarObjects2= [];
gdjs.EndCode.GDPlayerObjects1= [];
gdjs.EndCode.GDPlayerObjects2= [];
gdjs.EndCode.GDBottomObjects1= [];
gdjs.EndCode.GDBottomObjects2= [];


gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDBackgroundObjects1Objects = Hashtable.newFrom({"Background": gdjs.EndCode.GDBackgroundObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDBackgroundObjects1Objects = Hashtable.newFrom({"Background": gdjs.EndCode.GDBackgroundObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDTeleportlineObjects1Objects = Hashtable.newFrom({"Teleportline": gdjs.EndCode.GDTeleportlineObjects1});
gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDTransparentButtonWithWhiteBlueBorderObjects1Objects = Hashtable.newFrom({"TransparentButtonWithWhiteBlueBorder": gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects1});
gdjs.EndCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.EndCode.GDBackgroundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDBackgroundObjects1Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.EndCode.GDBackgroundObjects1 */
{for(var i = 0, len = gdjs.EndCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDBackgroundObjects1[i].addForce(-(250), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.EndCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleportline"), gdjs.EndCode.GDTeleportlineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDBackgroundObjects1Objects, gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDTeleportlineObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.EndCode.GDBackgroundObjects1 */
{for(var i = 0, len = gdjs.EndCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.EndCode.GDBackgroundObjects1[i].setPosition(1187,-(2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EndCode.mapOfGDgdjs_9546EndCode_9546GDTransparentButtonWithWhiteBlueBorderObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.EndCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EndCode.GDTitleObjects1.length = 0;
gdjs.EndCode.GDTitleObjects2.length = 0;
gdjs.EndCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.EndCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.EndCode.GDTeleportlineObjects1.length = 0;
gdjs.EndCode.GDTeleportlineObjects2.length = 0;
gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.EndCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.EndCode.GDSettingsObjects1.length = 0;
gdjs.EndCode.GDSettingsObjects2.length = 0;
gdjs.EndCode.GDNewTextObjects1.length = 0;
gdjs.EndCode.GDNewTextObjects2.length = 0;
gdjs.EndCode.GDBackgroundObjects1.length = 0;
gdjs.EndCode.GDBackgroundObjects2.length = 0;
gdjs.EndCode.GDSkeletonObjects1.length = 0;
gdjs.EndCode.GDSkeletonObjects2.length = 0;
gdjs.EndCode.GDSanity_9595BarObjects1.length = 0;
gdjs.EndCode.GDSanity_9595BarObjects2.length = 0;
gdjs.EndCode.GDPlayerObjects1.length = 0;
gdjs.EndCode.GDPlayerObjects2.length = 0;
gdjs.EndCode.GDBottomObjects1.length = 0;
gdjs.EndCode.GDBottomObjects2.length = 0;

gdjs.EndCode.eventsList0(runtimeScene);

return;

}

gdjs['EndCode'] = gdjs.EndCode;
