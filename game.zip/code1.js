gdjs.MenuCode = {};
gdjs.MenuCode.GDTitleObjects1= [];
gdjs.MenuCode.GDTitleObjects2= [];
gdjs.MenuCode.GDWhiteSquareDecoratedButtonObjects1= [];
gdjs.MenuCode.GDWhiteSquareDecoratedButtonObjects2= [];
gdjs.MenuCode.GDTeleportlineObjects1= [];
gdjs.MenuCode.GDTeleportlineObjects2= [];
gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.MenuCode.GDSettingsObjects1= [];
gdjs.MenuCode.GDSettingsObjects2= [];
gdjs.MenuCode.GDBackgroundObjects1= [];
gdjs.MenuCode.GDBackgroundObjects2= [];
gdjs.MenuCode.GDSkeletonObjects1= [];
gdjs.MenuCode.GDSkeletonObjects2= [];
gdjs.MenuCode.GDSanity_9595BarObjects1= [];
gdjs.MenuCode.GDSanity_9595BarObjects2= [];
gdjs.MenuCode.GDPlayerObjects1= [];
gdjs.MenuCode.GDPlayerObjects2= [];
gdjs.MenuCode.GDBottomObjects1= [];
gdjs.MenuCode.GDBottomObjects2= [];


gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBackgroundObjects1Objects = Hashtable.newFrom({"Background": gdjs.MenuCode.GDBackgroundObjects1});
gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBackgroundObjects1Objects = Hashtable.newFrom({"Background": gdjs.MenuCode.GDBackgroundObjects1});
gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDTeleportlineObjects1Objects = Hashtable.newFrom({"Teleportline": gdjs.MenuCode.GDTeleportlineObjects1});
gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDTransparentButtonWithWhiteBlueBorderObjects1Objects = Hashtable.newFrom({"TransparentButtonWithWhiteBlueBorder": gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1});
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.MenuCode.GDBackgroundObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBackgroundObjects1Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDBackgroundObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDBackgroundObjects1[i].addForce(-(250), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.MenuCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Teleportline"), gdjs.MenuCode.GDTeleportlineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDBackgroundObjects1Objects, gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDTeleportlineObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDBackgroundObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDBackgroundObjects1[i].setPosition(1187,-(2));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_9546MenuCode_9546GDTransparentButtonWithWhiteBlueBorderObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDTitleObjects1.length = 0;
gdjs.MenuCode.GDTitleObjects2.length = 0;
gdjs.MenuCode.GDWhiteSquareDecoratedButtonObjects1.length = 0;
gdjs.MenuCode.GDWhiteSquareDecoratedButtonObjects2.length = 0;
gdjs.MenuCode.GDTeleportlineObjects1.length = 0;
gdjs.MenuCode.GDTeleportlineObjects2.length = 0;
gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.MenuCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.MenuCode.GDSettingsObjects1.length = 0;
gdjs.MenuCode.GDSettingsObjects2.length = 0;
gdjs.MenuCode.GDBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBackgroundObjects2.length = 0;
gdjs.MenuCode.GDSkeletonObjects1.length = 0;
gdjs.MenuCode.GDSkeletonObjects2.length = 0;
gdjs.MenuCode.GDSanity_9595BarObjects1.length = 0;
gdjs.MenuCode.GDSanity_9595BarObjects2.length = 0;
gdjs.MenuCode.GDPlayerObjects1.length = 0;
gdjs.MenuCode.GDPlayerObjects2.length = 0;
gdjs.MenuCode.GDBottomObjects1.length = 0;
gdjs.MenuCode.GDBottomObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);

return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
